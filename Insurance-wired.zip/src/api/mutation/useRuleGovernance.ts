import { useMutation, useQueryClient } from "@tanstack/react-query";

import { publishRuleGroup, rollbackRuleGroup } from "../client";

/** Publish / rollback a rule group's live version (owner/admin), then refresh the registry
 *  + audit so the console reflects the new published version immediately. */
export const useRuleGovernance = () => {
  const qc = useQueryClient();
  const invalidate = () => {
    qc.invalidateQueries({ queryKey: ["rule-groups"] });
    qc.invalidateQueries({ queryKey: ["rule-audit"] });
  };
  const publish = useMutation({
    mutationFn: ({ group, version }: { group: string; version: string }) =>
      publishRuleGroup(group, version),
    onSuccess: invalidate,
  });
  const rollback = useMutation({
    mutationFn: ({ group }: { group: string }) => rollbackRuleGroup(group),
    onSuccess: invalidate,
  });
  return { publish, rollback };
};
